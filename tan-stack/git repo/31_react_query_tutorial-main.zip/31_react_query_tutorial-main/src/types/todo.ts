export interface Todo {
  checked: boolean;
  title: string;
  description: string;
  id?: number;
}
