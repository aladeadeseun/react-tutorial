// import Projects from "./components/Projects";
// import Todos from "./components/Todos";

import Products from "./components/Products";

function App() {
  return (
    <>
      {/* <Todos /> */}
      {/* <Projects /> */}
      <Products />
    </>
  );
}

export default App;
